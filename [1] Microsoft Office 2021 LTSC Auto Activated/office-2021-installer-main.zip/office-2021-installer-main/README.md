# Microsoft Office LTSC Professional Plus 2021
Microsoft Office 2021 Installer using Office Deployment Tool 

- Close all Office apps
- Connect to the Internet
- Double-click script.bat

# Supported Product:
- Microsoft Office Professional Plus 2021

### Enjoy Office Professional Plus 2021 with full activation!✨
